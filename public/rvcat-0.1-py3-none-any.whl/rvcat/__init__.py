import numpy as np

from .program   import Program
from .processor import _processor
from .scheduler import _scheduler 

global _program = Program()
